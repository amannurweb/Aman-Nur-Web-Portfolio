// CURSOR
const cursor = document.querySelector('.cursor');
const ring = document.querySelector('.cursor-ring');
document.addEventListener('mousemove', e => {
  cursor.style.left = e.clientX + 'px';
  cursor.style.top = e.clientY + 'px';
  setTimeout(() => {
    ring.style.left = e.clientX + 'px';
    ring.style.top = e.clientY + 'px';
  }, 80);
});
document.querySelectorAll('a,button,.service-card,.project-card,.blog-card').forEach(el => {
  el.addEventListener('mouseenter', () => ring.style.transform = 'translate(-50%,-50%) scale(1.6)');
  el.addEventListener('mouseleave', () => ring.style.transform = 'translate(-50%,-50%) scale(1)');
});

// NAVIGATION
function navigateTo(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(pageId).classList.add('active');
  document.querySelectorAll('.nav-links a, .mobile-menu a').forEach(a => {
    a.classList.remove('active');
    if (a.dataset.page === pageId) a.classList.add('active');
  });
  document.querySelector('.mobile-menu').classList.remove('open');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  triggerAnimations();
}

document.querySelectorAll('[data-page]').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    navigateTo(link.dataset.page);
  });
});

// HAMBURGER
document.querySelector('.hamburger').addEventListener('click', () => {
  document.querySelector('.mobile-menu').classList.toggle('open');
});

// SCROLL ANIMATIONS
function triggerAnimations() {
  setTimeout(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry, i) => {
        if (entry.isIntersecting) {
          setTimeout(() => entry.target.classList.add('visible'), i * 80);
        }
      });
    }, { threshold: 0.1 });
    document.querySelectorAll('.observe').forEach(el => {
      el.classList.remove('visible');
      observer.observe(el);
    });

    // SKILL BARS
    const skillObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.querySelectorAll('.skill-fill').forEach(bar => {
            bar.style.width = bar.dataset.width;
          });
        }
      });
    }, { threshold: 0.3 });
    document.querySelectorAll('.skill-bars').forEach(sb => skillObserver.observe(sb));
  }, 100);
}

// COUNTER ANIMATION
function animateCounters() {
  document.querySelectorAll('.count-up').forEach(el => {
    const target = parseInt(el.dataset.target);
    let current = 0;
    const step = target / 50;
    const timer = setInterval(() => {
      current += step;
      if (current >= target) { el.textContent = target; clearInterval(timer); }
      else el.textContent = Math.floor(current);
    }, 30);
  });
}

// CONTACT FORM
document.getElementById('contactForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const btn = this.querySelector('.btn-submit');
  btn.textContent = '✅ Message Sent!';
  btn.style.background = '#00ff88';
  setTimeout(() => {
    btn.innerHTML = 'Send Message →';
    btn.style.background = '';
    this.reset();
  }, 3000);
});

// INIT
window.addEventListener('load', () => {
  triggerAnimations();
  setTimeout(animateCounters, 400);
});
