# Md Aman Ullah — Portfolio Website

Personal portfolio website for PHP Developer & Digital Marketer based in Saudi Arabia.

## 🚀 Live Demo
Deploy on GitHub Pages: `https://yourusername.github.io/portfolio`

## 📁 Structure
```
portfolio/
├── index.html          ← Main file (all 5 pages)
├── css/
│   └── style.css       ← All styles
├── js/
│   └── main.js         ← Navigation & animations
└── README.md
```

## ✨ Features
- 5 Pages: Home, Services, Projects, About, Blog, Contact
- Dark modern design
- Mobile responsive
- Smooth page transitions
- Animated skill bars & counters
- Contact form
- Custom cursor

## 🔧 Deploy to GitHub Pages

1. Create a new repo on GitHub (e.g., `portfolio`)
2. Upload all files
3. Go to **Settings → Pages**
4. Set Source to **main branch / root**
5. Your site will be live at `https://yourusername.github.io/portfolio`

## 📞 Contact
- WhatsApp: +966 555 963 438
- LinkedIn: linkedin.com/in/amannurweb
